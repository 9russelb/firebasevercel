import styled from 'styled-components';

const Items = styled.ul`

`;

const Item = styled.li`
  
`;

export {Items, Item};