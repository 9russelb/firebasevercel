import styled from 'styled-components';

const Providers = styled.ul`

`;


const Provider = styled.li`
    margin-bottom: 0.75rem;
`

export {Providers, Provider}