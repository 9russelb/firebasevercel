import styled from 'styled-components';

const Login = styled.form`
    button{
        margin-top:1rem;
    }
`;

export default Login;