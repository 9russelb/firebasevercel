import Brand from './brand';
 

export default Brand
 