import { AppBar } from "components/appbar";
import {Title} from "ui/title"


function ToDoPage(props) {
   
    return (
      <>
        <AppBar />
        <Title> Please Go Away</Title>
      </>
    )
  
}

export default ToDoPage;
